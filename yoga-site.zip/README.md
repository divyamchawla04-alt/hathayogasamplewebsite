# Yoga teacher website

Static site (HTML + CSS + JS). No build step.

## Put it online with GitHub Pages
1. Create a new GitHub repo (e.g. `yoga`), upload `index.html`, `style.css`, `script.js`.
2. Repo → Settings → Pages → Source: "Deploy from a branch" → Branch `main`, folder `/ (root)` → Save.
3. After ~1 minute your site is live at `https://<username>.github.io/<repo>/`.
   (Name the repo `<username>.github.io` to get `https://<username>.github.io/`.)

## Edit
- Name, contact, schedule, FAQ: `index.html` (search "Your Name", "you@example.com", "9999999999").
- WhatsApp number and email for the form: top of `script.js`.
- Photo: add `images/me.jpg` and uncomment the `<img>` line in the About section.
- Colours: variables at top of `style.css`.
